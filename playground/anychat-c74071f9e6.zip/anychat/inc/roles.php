<?php
/**
 * Roles. Owner = WordPress administrator.
 * - anychat_member: someone who signed up to be featured. Can only see their own features (front end).
 * - anychat_staff:  team member who runs the Features board in wp-admin.
 */

defined( 'ABSPATH' ) || exit;

function acwp_add_roles() {
	add_role( 'anychat_member', 'Featured member', array( 'read' => true ) );
	add_role( 'anychat_staff', 'Anychat staff', array( 'read' => true, 'upload_files' => true, 'acwp_manage_features' => true ) );
	$admin = get_role( 'administrator' );
	if ( $admin ) {
		$admin->add_cap( 'acwp_manage_features' );
	}
}

// Members never see wp-admin or the admin bar: they live on the front-end pages.
add_action( 'admin_init', function () {
	if ( wp_doing_ajax() || ! is_user_logged_in() ) {
		return;
	}
	$u = wp_get_current_user();
	if ( in_array( 'anychat_member', (array) $u->roles, true ) && ! current_user_can( 'acwp_manage_features' ) ) {
		wp_safe_redirect( home_url( '/me/' ) );
		exit;
	}
} );

add_filter( 'show_admin_bar', function ( $show ) {
	$u = wp_get_current_user();
	return in_array( 'anychat_member', (array) $u->roles, true ) ? false : $show;
} );
