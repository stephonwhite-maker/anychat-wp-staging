<?php
/** Small shared helpers. */

defined( 'ABSPATH' ) || exit;

const ACWP_TZ = 'America/Chicago';

/** Every status a feature can have, with the label the member sees and the board column it sits in. */
function acwp_statuses() {
	return array(
		'invited'       => array( 'label' => 'Pick your date',     'tone' => 'wait', 'col' => 'requested' ),
		'requested'     => array( 'label' => 'Waiting on approval', 'tone' => 'wait', 'col' => 'requested' ),
		'on_hold'       => array( 'label' => 'Being reviewed',      'tone' => 'wait', 'col' => 'on_hold' ),
		'needs_changes' => array( 'label' => 'Needs a change',      'tone' => 'wait', 'col' => 'on_hold' ),
		'approved'      => array( 'label' => 'Approved',            'tone' => 'go',   'col' => 'ready' ),
		'content_in'    => array( 'label' => 'Content received',    'tone' => 'go',   'col' => 'ready' ),
		'in_production' => array( 'label' => 'In production',       'tone' => 'go',   'col' => 'production' ),
		'scheduled'     => array( 'label' => 'Scheduled',           'tone' => 'go',   'col' => 'production' ),
		'posted'        => array( 'label' => 'Live',                'tone' => 'go',   'col' => 'live' ),
		'declined'      => array( 'label' => 'Pick another date',   'tone' => 'no',   'col' => 'closed' ),
		'closed'        => array( 'label' => 'Closed',              'tone' => 'no',   'col' => 'closed' ),
	);
}

/** Statuses that hold a slot (nobody else can book it). Same list as WAOL lib/features.js HOLDS. */
function acwp_holding_statuses() {
	return array( 'requested', 'approved', 'content_in', 'scheduled', 'in_production', 'posted', 'on_hold', 'needs_changes' );
}

/** Statuses where the member may still add files. Same as WAOL UPLOADS_OPEN. */
function acwp_upload_statuses() {
	return array( 'requested', 'on_hold', 'approved', 'content_in', 'needs_changes' );
}

function acwp_content_types() {
	return array( 'Event', 'Business or brand', 'Food and drink', 'Music', 'Art', 'Product or launch', 'Community', 'Other' );
}

/** A feature's fields, read from post meta in one go. */
function acwp_feature( $post ) {
	$post = get_post( $post );
	if ( ! $post || 'acwp_feature' !== $post->post_type ) {
		return null;
	}
	$m = fn( $k, $d = '' ) => ( '' !== ( $v = get_post_meta( $post->ID, "_acwp_{$k}", true ) ) ? $v : $d );
	return array(
		'id'           => $post->ID,
		'status'       => $m( 'status', 'requested' ),
		'token'        => $m( 'token' ),
		'name'         => $m( 'name' ),
		'email'        => $m( 'email' ),
		'phone'        => $m( 'phone' ),
		'founding'     => (bool) $m( 'founding', 0 ),
		'business'     => $m( 'business' ),
		'handle'       => $m( 'handle' ),
		'content_type' => $m( 'content_type' ),
		'story'        => $m( 'story' ),
		'event'        => $m( 'event' ),
		'event_date'   => $m( 'event_date' ),
		'message'      => $m( 'message' ),
		'slot_at'      => (int) $m( 'slot_at', 0 ),
		'notes'        => $m( 'notes' ),
		'source'       => $m( 'source', 'wordpress' ),
		'history'      => (array) get_post_meta( $post->ID, '_acwp_history', true ) ?: array(),
		'user_id'      => (int) $post->post_author,
		'created'      => $post->post_date,
	);
}

function acwp_set( $id, $fields ) {
	foreach ( $fields as $k => $v ) {
		update_post_meta( $id, "_acwp_{$k}", $v );
	}
}

/** Add a line to the feature's history (who did what, when). */
function acwp_log( $id, $what ) {
	$h   = (array) get_post_meta( $id, '_acwp_history', true );
	$h   = array_filter( $h );
	$h[] = array( 'at' => time(), 'what' => $what, 'by' => get_current_user_id() );
	update_post_meta( $id, '_acwp_history', array_values( $h ) );
}

function acwp_feature_by_token( $token ) {
	$token = preg_replace( '/[^A-Za-z0-9_-]/', '', (string) $token );
	if ( strlen( $token ) < 20 ) {
		return null;
	}
	$q = get_posts( array( 'post_type' => 'acwp_feature', 'post_status' => 'any', 'numberposts' => 1, 'meta_key' => '_acwp_token', 'meta_value' => $token, 'fields' => 'ids' ) );
	return $q ? acwp_feature( $q[0] ) : null;
}

function acwp_new_token() {
	return rtrim( strtr( base64_encode( random_bytes( 18 ) ), '+/', '-_' ), '=' );
}

/** "Saturday, November 21 at 12:00 PM Central". */
function acwp_slot_label( $ts ) {
	if ( ! $ts ) {
		return 'No date yet';
	}
	$d = new DateTime( '@' . (int) $ts );
	$d->setTimezone( new DateTimeZone( ACWP_TZ ) );
	return $d->format( 'l, F j \a\t g:i A' ) . ' Central';
}

function acwp_portal_url( $f ) {
	return add_query_arg( 't', $f['token'], home_url( '/feature/' ) );
}

function acwp_handle( $h ) {
	$h = strtolower( trim( (string) $h ) );
	$h = preg_replace( '#^https?://(www\.)?instagram\.com/#i', '', $h );
	$h = preg_replace( '#[/?\#].*$#', '', ltrim( $h, '@' ) );
	return substr( preg_replace( '/[^a-z0-9._]/', '', $h ), 0, 40 );
}

function acwp_phone( $v ) {
	$d = preg_replace( '/\D/', '', (string) $v );
	$d = preg_replace( '/^1(?=\d{10}$)/', '', $d );
	return preg_match( '/^\d{10}$/', $d ) ? $d : '';
}

function acwp_phone_label( $d ) {
	return $d ? sprintf( '(%s) %s-%s', substr( $d, 0, 3 ), substr( $d, 3, 3 ), substr( $d, 6 ) ) : '';
}
