<?php
/**
 * Chunked, resumable uploads straight into the WordPress Media Library.
 *
 * The browser cuts each file into ACWP_CHUNK pieces and sends them one at a time to
 * POST /wp-json/anychat/v1/upload. A piece that fails is retried; if the page is closed, the next try asks
 * GET /upload/status which pieces already arrived and skips them. When the last piece lands, the pieces are
 * joined and the file becomes a WordPress attachment of the feature (post_parent), so it shows in wp-admin.
 *
 * Pieces wait in wp-content/uploads/acwp-chunks/<upload id>/ (in Dropbox, with the rest of the uploads).
 */

defined( 'ABSPATH' ) || exit;

const ACWP_CHUNK      = 2 * 1024 * 1024;     // 2 MB pieces: under PHP's default upload limit everywhere
const ACWP_MAX_FILE   = 2 * 1024 * 1024 * 1024; // 2 GB per file
const ACWP_MAX_FILES  = 20;                  // per feature, same as WAOL's pre-approval cap

function acwp_allowed_mime( $mime ) {
	return (bool) preg_match( '#^(image/(jpeg|png|webp|heic|heif|gif)|video/(mp4|quicktime|webm|x-m4v))$#', (string) $mime );
}

function acwp_chunk_dir( $upload_id ) {
	$base = wp_get_upload_dir()['basedir'] . '/acwp-chunks';
	if ( ! is_dir( $base ) ) {
		wp_mkdir_p( $base );
		@file_put_contents( $base . '/index.html', '' );
		@file_put_contents( $base . '/.htaccess', "Deny from all\n" );
	}
	return $base . '/' . preg_replace( '/[^A-Za-z0-9_-]/', '', $upload_id );
}

/** Which pieces of this upload have already arrived. */
function acwp_chunks_received( $upload_id ) {
	$dir = acwp_chunk_dir( $upload_id );
	if ( ! is_dir( $dir ) ) {
		return array();
	}
	$got = array();
	foreach ( glob( $dir . '/*.part' ) as $p ) {
		$got[] = (int) basename( $p, '.part' );
	}
	sort( $got );
	return $got;
}

/**
 * Save one piece. Returns array( 'done' => false, 'received' => [...] ) or, on the last piece,
 * array( 'done' => true, 'file' => {...} ). WP_Error with a plain message on any problem.
 */
function acwp_save_chunk( $f, $p, $tmp ) {
	if ( ! in_array( $f['status'], acwp_upload_statuses(), true ) || ! $f['slot_at'] ) {
		return new WP_Error( 'closed', 'Uploads are closed for this feature.', array( 'status' => 403 ) );
	}
	$upload_id = preg_replace( '/[^A-Za-z0-9_-]/', '', (string) ( $p['upload_id'] ?? '' ) );
	$index     = (int) ( $p['index'] ?? -1 );
	$total     = (int) ( $p['total'] ?? 0 );
	$size      = (int) ( $p['size'] ?? 0 );
	$mime      = (string) ( $p['type'] ?? '' );
	$name      = sanitize_file_name( (string) ( $p['name'] ?? 'upload' ) );
	if ( strlen( $upload_id ) < 12 || $index < 0 || $total < 1 || $index >= $total || $total > ceil( ACWP_MAX_FILE / ACWP_CHUNK ) + 1 ) {
		return new WP_Error( 'bad', 'That upload got mixed up. Try the file again.', array( 'status' => 400 ) );
	}
	if ( ! acwp_allowed_mime( $mime ) ) {
		return new WP_Error( 'type', 'Send photos (JPG, PNG, HEIC, WebP) or videos (MP4, MOV).', array( 'status' => 415 ) );
	}
	if ( $size > ACWP_MAX_FILE ) {
		return new WP_Error( 'size', 'That file is over 2 GB. Trim it or send a smaller export.', array( 'status' => 413 ) );
	}
	if ( 0 === $index && count( acwp_feature_files( $f['id'] ) ) >= ACWP_MAX_FILES ) {
		return new WP_Error( 'count', 'You can send up to ' . ACWP_MAX_FILES . ' files. Remove one to add another.', array( 'status' => 409 ) );
	}
	if ( ! $tmp || ! file_exists( $tmp ) ) {
		return new WP_Error( 'missing', 'A piece of the file did not arrive. Trying again usually fixes it.', array( 'status' => 400 ) );
	}
	$dir = acwp_chunk_dir( $upload_id );
	wp_mkdir_p( $dir );
	// Remember who this upload belongs to, so another feature's token can't finish it.
	$owner = $dir . '/owner';
	if ( ! file_exists( $owner ) ) {
		file_put_contents( $owner, (string) $f['id'] );
	} elseif ( trim( file_get_contents( $owner ) ) !== (string) $f['id'] ) {
		return new WP_Error( 'bad', 'That upload got mixed up. Try the file again.', array( 'status' => 403 ) );
	}
	if ( ! @move_uploaded_file( $tmp, "$dir/$index.part" ) && ! @rename( $tmp, "$dir/$index.part" ) ) {
		return new WP_Error( 'disk', 'We could not save that piece. Try again in a minute.', array( 'status' => 500 ) );
	}
	$got = acwp_chunks_received( $upload_id );
	if ( count( $got ) < $total ) {
		return array( 'done' => false, 'received' => $got );
	}
	return acwp_finish_upload( $f, $upload_id, $total, $name, $mime, $size );
}

/** Join the pieces and turn them into a Media Library attachment of the feature. */
function acwp_finish_upload( $f, $upload_id, $total, $name, $mime, $size ) {
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	$dir    = acwp_chunk_dir( $upload_id );
	$joined = "$dir/joined";
	$out    = fopen( $joined, 'wb' );
	for ( $i = 0; $i < $total; $i++ ) {
		$in = fopen( "$dir/$i.part", 'rb' );
		stream_copy_to_stream( $in, $out );
		fclose( $in );
	}
	fclose( $out );
	if ( $size && filesize( $joined ) !== $size ) {
		acwp_rm_dir( $dir );
		return new WP_Error( 'size', 'The file came through incomplete. Try it again.', array( 'status' => 422 ) );
	}
	$check = wp_check_filetype_and_ext( $joined, $name );
	$real  = $check['type'] ?: $mime;
	if ( function_exists( 'mime_content_type' ) ) {
		$sniff = mime_content_type( $joined );
		if ( $sniff && ! acwp_allowed_mime( $sniff ) && 'application/octet-stream' !== $sniff ) {
			acwp_rm_dir( $dir );
			return new WP_Error( 'type', 'That file is not a photo or video we can use.', array( 'status' => 415 ) );
		}
	}
	$GLOBALS['acwp_upload_feature'] = $f['id'];
	add_filter( 'upload_dir', 'acwp_feature_upload_dir' );
	$id = media_handle_sideload( array( 'name' => $name, 'tmp_name' => $joined, 'type' => $real, 'size' => filesize( $joined ) ), $f['id'], null, array( 'post_author' => $f['user_id'] ) );
	remove_filter( 'upload_dir', 'acwp_feature_upload_dir' );
	acwp_rm_dir( $dir );
	if ( is_wp_error( $id ) ) {
		return new WP_Error( 'save', 'We could not add that file: ' . $id->get_error_message(), array( 'status' => 500 ) );
	}
	acwp_log( $f['id'], 'uploaded ' . $name );
	foreach ( acwp_feature_files( $f['id'] ) as $file ) {
		if ( $file['id'] === $id ) {
			return array( 'done' => true, 'file' => $file );
		}
	}
	return array( 'done' => true, 'file' => array( 'id' => $id ) );
}

/** Feature files go in uploads/features/<feature id>/ so they're easy to find in Dropbox. */
function acwp_feature_upload_dir( $d ) {
	$sub = '/features/' . (int) ( $GLOBALS['acwp_upload_feature'] ?? 0 );
	$d['subdir'] = $sub;
	$d['path']   = $d['basedir'] . $sub;
	$d['url']    = $d['baseurl'] . $sub;
	return $d;
}

function acwp_rm_dir( $dir ) {
	foreach ( (array) glob( $dir . '/*' ) as $p ) {
		@unlink( $p );
	}
	@rmdir( $dir );
}

/** Remove a member's file (only while uploads are open). */
function acwp_remove_file( $f, $attachment_id ) {
	$a = get_post( (int) $attachment_id );
	if ( ! $a || (int) $a->post_parent !== (int) $f['id'] ) {
		return new WP_Error( 'nope', 'That file is not on this feature.', array( 'status' => 404 ) );
	}
	if ( ! in_array( $f['status'], acwp_upload_statuses(), true ) ) {
		return new WP_Error( 'closed', 'Files are locked once production starts.', array( 'status' => 403 ) );
	}
	wp_delete_attachment( $a->ID, true );
	acwp_log( $f['id'], 'removed a file' );
	return true;
}

// Clean up pieces of uploads that were abandoned more than a day ago.
add_action( 'acwp_daily', function () {
	foreach ( (array) glob( wp_get_upload_dir()['basedir'] . '/acwp-chunks/*', GLOB_ONLYDIR ) as $d ) {
		if ( filemtime( $d ) < time() - DAY_IN_SECONDS ) {
			acwp_rm_dir( $d );
		}
	}
} );
add_action( 'init', function () {
	if ( ! wp_next_scheduled( 'acwp_daily' ) ) {
		wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'acwp_daily' );
	}
} );

// Keep members' originals full size: Instagram production needs the real file, not WordPress's 2560px copy.
add_filter( 'big_image_size_threshold', '__return_false' );
