<?php
/**
 * REST API under /wp-json/anychat/v1/
 *
 * Public (portal token in the request, like the WAOL /f/<token> links):
 *   GET  slots                          open posting times
 *   POST request                        new feature request from the waitlist form
 *   POST login                          email me a sign-in link
 *   GET  feature?t=                     the member's view of one feature
 *   POST feature/pick                   pick or change the date (invited / declined)
 *   POST feature/send                   "Send it over": files are ready (status content_in)
 *   POST upload                         one piece of a file (chunked)
 *   GET  upload/status?t=&upload_id=    which pieces already arrived (resume)
 *   POST upload/remove                  remove a file
 *
 * For the Vercel Anychat engine (application password, acwp_manage_features), used later by the
 * preview-only bridge (Phase 3):
 *   GET  features                       features ready to produce, with file URLs
 *   POST features/<id>/status           report scheduled / posted / metrics
 */

defined( 'ABSPATH' ) || exit;

add_action( 'rest_api_init', function () {
	$ns   = 'anychat/v1';
	$open = '__return_true';
	$tok  = array( 't' => array( 'required' => true ) );

	register_rest_route( $ns, '/slots', array( 'methods' => 'GET', 'permission_callback' => $open, 'callback' => fn() => array( 'slots' => acwp_open_slots() ) ) );

	register_rest_route( $ns, '/request', array( 'methods' => 'POST', 'permission_callback' => $open, 'callback' => function ( WP_REST_Request $r ) {
		if ( acwp_rate_limited( 'request', 8 ) ) {
			return new WP_Error( 'slow', 'Too many tries. Wait a few minutes.', array( 'status' => 429 ) );
		}
		if ( '' !== (string) $r->get_param( 'website' ) ) { // honeypot
			return array( 'ok' => true );
		}
		$f = acwp_submit_request( $r->get_params() );
		if ( is_wp_error( $f ) ) {
			$f->add_data( array( 'status' => 400 ) );
			return $f;
		}
		return array( 'ok' => true, 'portal' => acwp_portal_url( $f ), 'token' => $f['token'], 'slot_label' => acwp_slot_label( $f['slot_at'] ) );
	} ) );

	register_rest_route( $ns, '/login', array( 'methods' => 'POST', 'permission_callback' => $open, 'callback' => function ( WP_REST_Request $r ) {
		if ( ! acwp_rate_limited( 'login', 5 ) ) {
			acwp_send_login( (string) $r->get_param( 'email' ) );
		}
		return array( 'ok' => true, 'message' => 'If that email has a member page, a sign-in link is on its way.' );
	} ) );

	register_rest_route( $ns, '/feature', array( 'methods' => 'GET', 'permission_callback' => $open, 'args' => $tok, 'callback' => function ( WP_REST_Request $r ) {
		$f = acwp_feature_by_token( $r['t'] );
		return $f ? acwp_public_view( $f ) : new WP_Error( 'gone', 'This link is not active.', array( 'status' => 404 ) );
	} ) );

	register_rest_route( $ns, '/feature/pick', array( 'methods' => 'POST', 'permission_callback' => $open, 'args' => $tok, 'callback' => function ( WP_REST_Request $r ) {
		$f = acwp_feature_by_token( $r['t'] );
		if ( ! $f || ! in_array( $f['status'], array( 'invited', 'declined' ), true ) ) {
			return new WP_Error( 'nope', 'You can’t change the date now.', array( 'status' => 403 ) );
		}
		$at = acwp_check_slot( $r['slotDate'], $r['slotTime'], $f['email'], $f['id'] );
		if ( is_wp_error( $at ) ) {
			$at->add_data( array( 'status' => 400 ) );
			return $at;
		}
		acwp_set( $f['id'], array( 'slot_at' => $at, 'status' => 'requested' ) );
		acwp_log( $f['id'], 'picked ' . acwp_slot_label( $at ) );
		acwp_tell_owner( 'Date picked: ' . ( $f['business'] ?: $f['name'] ), array( esc_html( $f['name'] ) . ' asked for ' . esc_html( acwp_slot_label( $at ) ) . '.' ), $f['id'] );
		return acwp_public_view( acwp_feature( $f['id'] ) );
	} ) );

	register_rest_route( $ns, '/feature/send', array( 'methods' => 'POST', 'permission_callback' => $open, 'args' => $tok, 'callback' => function ( WP_REST_Request $r ) {
		$f = acwp_feature_by_token( $r['t'] );
		if ( ! $f || ! in_array( $f['status'], array( 'approved', 'needs_changes', 'requested', 'on_hold' ), true ) ) {
			return new WP_Error( 'nope', 'This feature isn’t taking files right now.', array( 'status' => 403 ) );
		}
		$files = acwp_feature_files( $f['id'] );
		if ( ! $files ) {
			return new WP_Error( 'empty', 'Add at least one photo or video first.', array( 'status' => 400 ) );
		}
		$caption = sanitize_textarea_field( (string) $r->get_param( 'caption' ) );
		if ( $caption ) {
			acwp_set( $f['id'], array( 'caption' => $caption ) );
		}
		// Before approval we just mark the files ready; after approval it moves to Content received.
		if ( in_array( $f['status'], array( 'approved', 'needs_changes' ), true ) ) {
			acwp_set( $f['id'], array( 'status' => 'content_in' ) );
			acwp_log( $f['id'], 'content_in' );
		} else {
			acwp_set( $f['id'], array( 'content_ready' => 1 ) );
			acwp_log( $f['id'], 'files ready before approval' );
		}
		acwp_tell_owner( 'Files in: ' . ( $f['business'] ?: $f['name'] ), array( sprintf( '%s sent %d file%s for %s.', esc_html( $f['name'] ), count( $files ), 1 === count( $files ) ? '' : 's', esc_html( acwp_slot_label( $f['slot_at'] ) ) ) ), $f['id'] );
		return acwp_public_view( acwp_feature( $f['id'] ) );
	} ) );

	register_rest_route( $ns, '/upload', array( 'methods' => 'POST', 'permission_callback' => $open, 'callback' => function ( WP_REST_Request $r ) {
		$f = acwp_feature_by_token( $r->get_param( 't' ) );
		if ( ! $f ) {
			return new WP_Error( 'gone', 'This link is not active.', array( 'status' => 404 ) );
		}
		$file = $r->get_file_params()['chunk'] ?? null;
		$res  = acwp_save_chunk( $f, $r->get_params(), $file['tmp_name'] ?? '' );
		return $res;
	} ) );

	register_rest_route( $ns, '/upload/status', array( 'methods' => 'GET', 'permission_callback' => $open, 'args' => $tok, 'callback' => function ( WP_REST_Request $r ) {
		$f = acwp_feature_by_token( $r['t'] );
		return $f ? array( 'received' => acwp_chunks_received( (string) $r['upload_id'] ) ) : new WP_Error( 'gone', 'This link is not active.', array( 'status' => 404 ) );
	} ) );

	register_rest_route( $ns, '/upload/remove', array( 'methods' => 'POST', 'permission_callback' => $open, 'args' => $tok, 'callback' => function ( WP_REST_Request $r ) {
		$f = acwp_feature_by_token( $r['t'] );
		$ok = $f ? acwp_remove_file( $f, (int) $r['id'] ) : new WP_Error( 'gone', 'This link is not active.', array( 'status' => 404 ) );
		return is_wp_error( $ok ) ? $ok : acwp_public_view( acwp_feature( $f['id'] ) );
	} ) );

	// ---- for the Anychat engine (Phase 3) ----
	$staff = fn() => current_user_can( 'acwp_manage_features' );
	register_rest_route( $ns, '/features', array( 'methods' => 'GET', 'permission_callback' => $staff, 'callback' => function ( WP_REST_Request $r ) {
		$status = array_filter( explode( ',', (string) ( $r['status'] ?: 'approved,content_in' ) ) );
		$ids    = get_posts( array( 'post_type' => 'acwp_feature', 'post_status' => 'any', 'numberposts' => 200, 'fields' => 'ids', 'meta_query' => array( array( 'key' => '_acwp_status', 'value' => $status, 'compare' => 'IN' ) ) ) );
		return array( 'features' => array_map( fn( $id ) => acwp_engine_view( acwp_feature( $id ) ), $ids ) );
	} ) );
	register_rest_route( $ns, '/features/(?P<id>\d+)/status', array( 'methods' => 'POST', 'permission_callback' => $staff, 'callback' => function ( WP_REST_Request $r ) {
		$f = acwp_feature( (int) $r['id'] );
		if ( ! $f ) {
			return new WP_Error( 'gone', 'No such feature.', array( 'status' => 404 ) );
		}
		$status = (string) $r['status'];
		if ( in_array( $status, array( 'scheduled', 'posted' ), true ) ) {
			acwp_set( $f['id'], array( 'status' => $status ) );
			acwp_log( $f['id'], $status . ' (Anychat engine)' );
		}
		if ( $r['post_url'] ) {
			acwp_set( $f['id'], array( 'post_url' => esc_url_raw( $r['post_url'] ) ) );
		}
		if ( is_array( $r['metrics'] ) ) {
			acwp_set( $f['id'], array( 'metrics' => array_map( 'intval', $r['metrics'] ), 'metrics_at' => time() ) );
		}
		return acwp_engine_view( acwp_feature( $f['id'] ) );
	} ) );
} );

/** What the member's portal sees. No notes, history or other people's data. */
function acwp_public_view( $f ) {
	$s = acwp_statuses()[ $f['status'] ] ?? array( 'label' => $f['status'], 'tone' => '' );
	return array(
		'status'      => $f['status'],
		'label'       => $s['label'],
		'tone'        => $s['tone'],
		'name'        => $f['name'],
		'business'    => $f['business'],
		'slot_label'  => acwp_slot_label( $f['slot_at'] ),
		'can_upload'  => in_array( $f['status'], acwp_upload_statuses(), true ) && $f['slot_at'] > 0,
		'can_send'    => in_array( $f['status'], array( 'approved', 'needs_changes', 'requested', 'on_hold' ), true ),
		'can_pick'    => in_array( $f['status'], array( 'invited', 'declined' ), true ),
		'content_ready' => (bool) get_post_meta( $f['id'], '_acwp_content_ready', true ),
		'change_note' => 'needs_changes' === $f['status'] ? (string) get_post_meta( $f['id'], '_acwp_change_note', true ) : '',
		'caption'     => (string) get_post_meta( $f['id'], '_acwp_caption', true ),
		'post_url'    => (string) get_post_meta( $f['id'], '_acwp_post_url', true ),
		'files'       => array_map( fn( $x ) => array_intersect_key( $x, array_flip( array( 'id', 'url', 'type', 'name', 'w', 'h' ) ) ), acwp_feature_files( $f['id'] ) ),
		'max_files'   => ACWP_MAX_FILES,
		'chunk'       => ACWP_CHUNK,
	);
}

/** What the Anychat engine needs to build the Instagram draft. No phone numbers. */
function acwp_engine_view( $f ) {
	return array(
		'id' => $f['id'], 'status' => $f['status'], 'slot_at' => $f['slot_at'], 'slot_label' => acwp_slot_label( $f['slot_at'] ),
		'name' => $f['name'], 'business' => $f['business'], 'handle' => $f['handle'], 'content_type' => $f['content_type'],
		'story' => $f['story'], 'event' => $f['event'], 'event_date' => $f['event_date'],
		'caption' => (string) get_post_meta( $f['id'], '_acwp_caption', true ),
		'files' => acwp_feature_files( $f['id'] ),
	);
}

/** Simple per-IP limit: at most $max calls per 10 minutes for this action. */
function acwp_rate_limited( $action, $max ) {
	$ip  = preg_replace( '/[^0-9a-f:.]/i', '', (string) ( $_SERVER['REMOTE_ADDR'] ?? '' ) );
	$key = 'acwp_rl_' . md5( $action . $ip );
	$n   = (int) get_transient( $key );
	set_transient( $key, $n + 1, 10 * MINUTE_IN_SECONDS );
	return $n >= $max;
}
