<?php
/**
 * Email. Every message goes through acwp_mail(), which sends it with wp_mail() AND saves a copy in the
 * Outbox (wp-admin > Anychat > Outbox). On the local Playground wp_mail can't reach the internet, so the
 * Outbox is where you read what members would get, sign-in links included.
 * Nothing here depends on Slack.
 */

defined( 'ABSPATH' ) || exit;

add_action( 'init', function () {
	register_post_type( 'acwp_mail', array( 'public' => false, 'show_ui' => false, 'supports' => array( 'title', 'editor' ) ) );
} );

function acwp_mail( $to, $subject, $lines, $args = array() ) {
	$args = wp_parse_args( $args, array( 'button' => null, 'feature' => 0, 'kind' => 'member' ) );
	$html = acwp_mail_html( $subject, (array) $lines, $args['button'] );
	$sent = (bool) wp_mail( $to, $subject, $html, array( 'Content-Type: text/html; charset=UTF-8' ) );
	$id   = wp_insert_post( array( 'post_type' => 'acwp_mail', 'post_status' => 'publish', 'post_title' => $subject, 'post_content' => $html ) );
	if ( $id && ! is_wp_error( $id ) ) {
		update_post_meta( $id, '_to', $to );
		update_post_meta( $id, '_sent', $sent ? 1 : 0 );
		update_post_meta( $id, '_feature', (int) $args['feature'] );
		update_post_meta( $id, '_kind', $args['kind'] );
	}
	return $sent;
}

/** Plain, readable email: logo text, lines, one button. No em dashes in copy. */
function acwp_mail_html( $title, $lines, $button ) {
	$body = '';
	foreach ( $lines as $l ) {
		$body .= '<p style="margin:0 0 14px;font-size:16px;line-height:1.5;color:#111">' . wp_kses_post( $l ) . '</p>';
	}
	if ( $button ) {
		$body .= '<p style="margin:22px 0"><a href="' . esc_url( $button[1] ) . '" style="background:#111;color:#fff;text-decoration:none;padding:12px 20px;border-radius:10px;font-weight:600;display:inline-block">' . esc_html( $button[0] ) . '</a></p>';
	}
	return '<!doctype html><html><body style="margin:0;background:#f6f5f1;font-family:Inter,Arial,sans-serif"><div style="max-width:560px;margin:0 auto;padding:32px 24px">'
		. '<p style="font-weight:800;letter-spacing:.02em;margin:0 0 24px">WE ARE ONE LOU</p>'
		. '<h1 style="font-size:22px;margin:0 0 16px;color:#111">' . esc_html( $title ) . '</h1>' . $body
		. '<p style="margin:28px 0 0;font-size:13px;color:#666">You got this because you asked to be featured on We Are One Lou.</p></div></body></html>';
}

/** Tell the owner something happened (replaces the Slack thread). */
function acwp_tell_owner( $subject, $lines, $feature_id = 0 ) {
	$url = admin_url( 'admin.php?page=acwp-features' . ( $feature_id ? '&feature=' . (int) $feature_id : '' ) );
	return acwp_mail( acwp_settings()['owner_email'], $subject, $lines, array( 'button' => array( 'Open on the Features board', $url ), 'feature' => $feature_id, 'kind' => 'owner' ) );
}
