<?php
/**
 * wp-admin > Anychat
 *   Features  board (Requested / Ready to produce / In production / On hold / Live / Closed) + one request's detail
 *   Outbox    every email the system sent (sign-in links included), since local WordPress can't send mail
 *   Settings  posting times, owner email
 * Steps run through admin-post.php?action=acwp_step with a nonce. Each one logs to history and emails the member.
 */

defined( 'ABSPATH' ) || exit;

add_action( 'admin_menu', function () {
	add_menu_page( 'Anychat', 'Anychat', 'acwp_manage_features', 'acwp-features', 'acwp_board_page', 'dashicons-format-chat', 3 );
	add_submenu_page( 'acwp-features', 'Features', 'Features', 'acwp_manage_features', 'acwp-features', 'acwp_board_page' );
	add_submenu_page( 'acwp-features', 'Outbox', 'Outbox', 'acwp_manage_features', 'acwp-outbox', 'acwp_outbox_page' );
	add_submenu_page( 'acwp-features', 'Settings', 'Settings', 'manage_options', 'acwp-settings', 'acwp_settings_page' );
} );

add_action( 'admin_enqueue_scripts', function ( $hook ) {
	if ( str_contains( (string) $hook, 'acwp' ) ) {
		wp_enqueue_style( 'acwp-admin', ACWP_URL . 'assets/admin.css', array(), ACWP_VERSION );
	}
} );

/** The steps, which statuses each one is offered on, and its button label. */
function acwp_steps() {
	return array(
		'approve'    => array( 'Approve', array( 'requested', 'on_hold', 'needs_changes' ) ),
		'hold'       => array( 'Put on hold', array( 'requested', 'approved', 'content_in' ) ),
		'resume'     => array( 'Resume', array( 'on_hold' ) ),
		'changes'    => array( 'Needs changes', array( 'requested', 'approved', 'content_in', 'on_hold' ) ),
		'production' => array( 'Mark in production', array( 'approved', 'content_in' ) ),
		'scheduled'  => array( 'Mark scheduled', array( 'in_production' ) ),
		'posted'     => array( 'Mark live', array( 'in_production', 'scheduled' ) ),
		'decline'    => array( 'Decline', array( 'requested', 'on_hold', 'needs_changes' ) ),
		'close'      => array( 'Close', array( 'approved', 'content_in', 'in_production', 'scheduled', 'posted', 'declined', 'on_hold', 'needs_changes' ) ),
		'force'      => array( 'Force approve', array( 'declined', 'closed' ) ),
	);
}

function acwp_board_page() {
	if ( ! empty( $_GET['feature'] ) ) {
		acwp_feature_detail( (int) $_GET['feature'] );
		return;
	}
	$cols = array( 'requested' => 'Requested', 'ready' => 'Ready to produce', 'production' => 'In production', 'on_hold' => 'On hold', 'live' => 'Live', 'closed' => 'Closed' );
	$by   = array_fill_keys( array_keys( $cols ), array() );
	foreach ( get_posts( array( 'post_type' => 'acwp_feature', 'post_status' => 'any', 'numberposts' => 300, 'orderby' => 'date', 'order' => 'DESC' ) ) as $p ) {
		$f = acwp_feature( $p );
		$by[ acwp_statuses()[ $f['status'] ]['col'] ?? 'requested' ][] = $f;
	}
	foreach ( $by as &$list ) {
		usort( $list, fn( $a, $b ) => ( $a['slot_at'] ?: PHP_INT_MAX ) <=> ( $b['slot_at'] ?: PHP_INT_MAX ) );
	}
	unset( $list );
	echo '<div class="wrap acwp-admin"><h1>Features</h1>';
	acwp_admin_notice();
	echo '<p class="acwp-sub">Copy of WAOL Features on WordPress. Live Anychat is not affected. <a href="' . esc_url( home_url( '/get-featured/' ) ) . '" target="_blank">Waitlist page</a></p><div class="acwp-board">';
	foreach ( $cols as $key => $label ) {
		echo '<section class="acwp-col"><h2>' . esc_html( $label ) . ' <span>' . count( $by[ $key ] ) . '</span></h2>';
		foreach ( $by[ $key ] as $f ) {
			$s = acwp_statuses()[ $f['status'] ];
			$n = count( acwp_feature_files( $f['id'] ) );
			echo '<a class="acwp-cardlink" href="' . esc_url( admin_url( 'admin.php?page=acwp-features&feature=' . $f['id'] ) ) . '"><span class="acwp-pill ' . esc_attr( $s['tone'] ) . '">' . esc_html( $s['label'] ) . '</span>'
				. '<strong>' . esc_html( $f['business'] ?: $f['name'] ) . '</strong><em>' . esc_html( acwp_slot_label( $f['slot_at'] ) ) . '</em>'
				. '<small>' . esc_html( $f['name'] ) . ( $f['handle'] ? ' · @' . esc_html( $f['handle'] ) : '' ) . ' · ' . $n . ' file' . ( 1 === $n ? '' : 's' ) . ( $f['founding'] ? ' · Founding' : '' ) . '</small></a>';
		}
		if ( ! $by[ $key ] ) {
			echo '<p class="acwp-empty">Nothing here.</p>';
		}
		echo '</section>';
	}
	echo '</div></div>';
}

function acwp_feature_detail( $id ) {
	$f = acwp_feature( $id );
	if ( ! $f ) {
		echo '<div class="wrap"><h1>Not found</h1></div>';
		return;
	}
	$s     = acwp_statuses()[ $f['status'] ];
	$files = acwp_feature_files( $id );
	$back  = admin_url( 'admin.php?page=acwp-features' );
	echo '<div class="wrap acwp-admin"><p><a href="' . esc_url( $back ) . '">← Features</a></p>';
	acwp_admin_notice();
	echo '<h1>' . esc_html( $f['business'] ?: $f['name'] ) . ' <span class="acwp-pill ' . esc_attr( $s['tone'] ) . '">' . esc_html( $s['label'] ) . '</span></h1><div class="acwp-detail"><div>';

	// Steps
	echo '<section class="acwp-box"><h2>Next step</h2><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
	wp_nonce_field( 'acwp_step_' . $id );
	echo '<input type="hidden" name="action" value="acwp_step"><input type="hidden" name="id" value="' . (int) $id . '">'
		. '<label>Note to the member <span>(used by Needs changes and Reply by email)</span><textarea name="note" rows="3"></textarea></label>'
		. '<label>Post link <span>(for Mark live)</span><input name="post_url" type="url" placeholder="https://www.instagram.com/p/..."></label><div class="acwp-steps">';
	foreach ( acwp_steps() as $step => [ $label, $on ] ) {
		if ( in_array( $f['status'], $on, true ) ) {
			echo '<button class="button' . ( 'approve' === $step ? ' button-primary' : '' ) . '" name="step" value="' . esc_attr( $step ) . '"' . ( in_array( $step, array( 'decline', 'close' ), true ) ? ' onclick="return confirm(\'' . esc_js( $label ) . ' this request?\')"' : '' ) . '>' . esc_html( $label ) . '</button>';
		}
	}
	echo '<button class="button" name="step" value="reply">Reply by email</button></div></form></section>';

	// Files
	echo '<section class="acwp-box"><h2>Files (' . count( $files ) . ')</h2><div class="acwp-files">';
	foreach ( $files as $x ) {
		echo '<figure>' . ( 'video' === $x['type'] ? '<video src="' . esc_url( $x['url'] ) . '#t=0.5" controls preload="metadata"></video>' : '<img src="' . esc_url( $x['url'] ) . '" alt="">' )
			. '<figcaption><a href="' . esc_url( $x['url'] ) . '" download>' . esc_html( $x['name'] ) . '</a> · ' . esc_html( size_format( $x['size'] ) ) . ( $x['w'] ? ' · ' . (int) $x['w'] . '×' . (int) $x['h'] : '' ) . '</figcaption></figure>';
	}
	echo $files ? '' : '<p>No files yet.</p>';
	$cap = get_post_meta( $id, '_acwp_caption', true );
	echo '</div>' . ( $cap ? '<h3>Caption idea</h3><p>' . nl2br( esc_html( $cap ) ) . '</p>' : '' ) . '</section></div><div>';

	// Details
	$rows = array(
		'Slot' => acwp_slot_label( $f['slot_at'] ), 'Name' => $f['name'], 'Email' => $f['email'], 'Phone' => acwp_phone_label( $f['phone'] ),
		'Founding Member' => $f['founding'] ? 'Yes' : 'No', 'Business' => $f['business'], 'Instagram' => $f['handle'] ? '@' . $f['handle'] : '',
		'Content type' => $f['content_type'], 'The story' => $f['story'], 'Event' => $f['event'], 'Event date' => $f['event_date'], 'Message' => $f['message'],
		'Came from' => 'wordpress' === $f['source'] ? 'WordPress waitlist' : 'Copied from live Anychat (read-only export)',
	);
	echo '<section class="acwp-box"><h2>Details</h2><dl>';
	foreach ( array_filter( $rows ) as $k => $v ) {
		echo '<dt>' . esc_html( $k ) . '</dt><dd>' . nl2br( esc_html( $v ) ) . '</dd>';
	}
	echo '</dl><p><a class="button" href="' . esc_url( acwp_portal_url( $f ) ) . '" target="_blank">Open their page</a></p></section>';

	// Notes + history
	echo '<section class="acwp-box"><h2>Notes for production</h2><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
	wp_nonce_field( 'acwp_step_' . $id );
	echo '<input type="hidden" name="action" value="acwp_step"><input type="hidden" name="id" value="' . (int) $id . '"><textarea name="notes" rows="4">' . esc_textarea( $f['notes'] ) . '</textarea><p><button class="button" name="step" value="notes">Save notes</button></p></form></section>';
	echo '<section class="acwp-box"><h2>History</h2><ol class="acwp-hist">';
	foreach ( array_reverse( $f['history'] ) as $h ) {
		$who = ! empty( $h['by'] ) ? get_userdata( $h['by'] ) : null;
		echo '<li><b>' . esc_html( $h['what'] ) . '</b> <span>' . esc_html( wp_date( 'M j, g:i A', $h['at'] ) ) . ( $who ? ' · ' . esc_html( $who->display_name ) : '' ) . '</span></li>';
	}
	echo '</ol></section></div></div></div>';
}

add_action( 'admin_post_acwp_step', function () {
	$id = (int) ( $_POST['id'] ?? 0 );
	check_admin_referer( 'acwp_step_' . $id );
	if ( ! current_user_can( 'acwp_manage_features' ) ) {
		wp_die( 'Not allowed.' );
	}
	$r = acwp_run_step( $id, sanitize_key( $_POST['step'] ?? '' ), array(
		'note' => sanitize_textarea_field( wp_unslash( $_POST['note'] ?? '' ) ),
		'post_url' => esc_url_raw( wp_unslash( $_POST['post_url'] ?? '' ) ),
		'notes' => sanitize_textarea_field( wp_unslash( $_POST['notes'] ?? '' ) ),
	) );
	set_transient( 'acwp_notice_' . get_current_user_id(), is_wp_error( $r ) ? array( 'no', $r->get_error_message() ) : array( 'go', $r ), 60 );
	wp_safe_redirect( admin_url( 'admin.php?page=acwp-features&feature=' . $id ) );
	exit;
} );

/** Run one step on a feature. Returns a short "done" message or WP_Error. */
function acwp_run_step( $id, $step, $in = array() ) {
	$f = acwp_feature( $id );
	if ( ! $f ) {
		return new WP_Error( 'gone', 'No such feature.' );
	}
	$who   = $f['business'] ?: $f['name'];
	$steps = acwp_steps();
	if ( 'notes' === $step ) {
		acwp_set( $id, array( 'notes' => $in['notes'] ?? '' ) );
		return 'Notes saved.';
	}
	if ( 'reply' === $step ) {
		if ( empty( $in['note'] ) ) {
			return new WP_Error( 'note', 'Write the email in the note box first.' );
		}
		acwp_mail( $f['email'], 'A note about your feature', array( 'Hi ' . esc_html( $f['name'] ) . ',', nl2br( esc_html( $in['note'] ) ) ), array( 'button' => array( 'Open your feature page', acwp_portal_url( $f ) ), 'feature' => $id ) );
		acwp_log( $id, 'emailed: ' . wp_trim_words( $in['note'], 12 ) );
		return 'Email sent to ' . $f['email'] . '.';
	}
	if ( ! isset( $steps[ $step ] ) || ! in_array( $f['status'], $steps[ $step ][1], true ) ) {
		return new WP_Error( 'step', 'That step doesn’t apply right now.' );
	}
	$portal = array( 'Open your feature page', acwp_portal_url( $f ) );
	switch ( $step ) {
		case 'approve':
		case 'force':
			if ( 'force' === $step && ! empty( acwp_taken_slots( $id )[ $f['slot_at'] ] ) ) {
				return new WP_Error( 'taken', 'Someone else holds that slot now. Ask them to pick another date first.' );
			}
			$to = get_post_meta( $id, '_acwp_content_ready', true ) ? 'content_in' : 'approved';
			acwp_set( $id, array( 'status' => $to ) );
			acwp_mail( $f['email'], 'You’re in', array( 'Hi ' . esc_html( $f['name'] ) . ', your feature is approved for <b>' . esc_html( acwp_slot_label( $f['slot_at'] ) ) . '</b>.', 'content_in' === $to ? 'We have your files. We’ll build your post and put it up at your time.' : 'Upload your photos and videos so we can build your post.' ), array( 'button' => $portal, 'feature' => $id ) );
			break;
		case 'hold':
			acwp_set( $id, array( 'status' => 'on_hold', 'held_from' => $f['status'] ) );
			break; // silent, same as WAOL
		case 'resume':
			acwp_set( $id, array( 'status' => get_post_meta( $id, '_acwp_held_from', true ) ?: 'requested' ) );
			break;
		case 'changes':
			if ( empty( $in['note'] ) ) {
				return new WP_Error( 'note', 'Write what needs to change in the note box.' );
			}
			acwp_set( $id, array( 'status' => 'needs_changes', 'change_note' => $in['note'] ) );
			acwp_mail( $f['email'], 'One change before we post', array( 'Hi ' . esc_html( $f['name'] ) . ', we need one thing before your feature goes up:', '<b>' . nl2br( esc_html( $in['note'] ) ) . '</b>', 'Your upload page is open again.' ), array( 'button' => $portal, 'feature' => $id ) );
			break;
		case 'production':
			acwp_set( $id, array( 'status' => 'in_production' ) );
			acwp_mail( $f['email'], 'Your feature is in production', array( 'We’re building your post now. It goes up ' . esc_html( acwp_slot_label( $f['slot_at'] ) ) . '.' ), array( 'button' => $portal, 'feature' => $id ) );
			break;
		case 'scheduled':
			acwp_set( $id, array( 'status' => 'scheduled' ) );
			break;
		case 'posted':
			acwp_set( $id, array( 'status' => 'posted' ) + ( $in['post_url'] ? array( 'post_url' => $in['post_url'] ) : array() ) );
			acwp_mail( $f['email'], 'You’re live on We Are One Lou', array( 'Your feature is up. Share it with your people.' ), array( 'button' => $in['post_url'] ? array( 'See your post', $in['post_url'] ) : $portal, 'feature' => $id ) );
			break;
		case 'decline':
			acwp_set( $id, array( 'status' => 'declined' ) );
			acwp_mail( $f['email'], 'Pick another date', array( 'Hi ' . esc_html( $f['name'] ) . ', we can’t do ' . esc_html( acwp_slot_label( $f['slot_at'] ) ) . '. Pick another time that works for you.' ), array( 'button' => array( 'Pick another date', acwp_portal_url( $f ) ), 'feature' => $id ) );
			break;
		case 'close':
			acwp_set( $id, array( 'status' => 'closed' ) );
			break;
	}
	acwp_log( $id, $steps[ $step ][0] . ( 'changes' === $step ? ': ' . wp_trim_words( $in['note'], 12 ) : '' ) );
	return $steps[ $step ][0] . ' done for ' . $who . '.';
}

function acwp_admin_notice() {
	$n = get_transient( 'acwp_notice_' . get_current_user_id() );
	if ( $n ) {
		delete_transient( 'acwp_notice_' . get_current_user_id() );
		echo '<div class="notice notice-' . ( 'go' === $n[0] ? 'success' : 'error' ) . ' is-dismissible"><p>' . esc_html( $n[1] ) . '</p></div>';
	}
}

function acwp_outbox_page() {
	$open = (int) ( $_GET['mail'] ?? 0 );
	echo '<div class="wrap acwp-admin"><h1>Outbox</h1><p class="acwp-sub">Every email Anychat sent. On the local site nothing leaves this Mac, so sign-in links and member emails show up here to click.</p>';
	if ( $open && ( $m = get_post( $open ) ) && 'acwp_mail' === $m->post_type ) {
		echo '<p><a href="' . esc_url( admin_url( 'admin.php?page=acwp-outbox' ) ) . '">← Outbox</a></p><p><b>To:</b> ' . esc_html( get_post_meta( $open, '_to', true ) ) . '</p>'
			. '<iframe class="acwp-mail" sandbox="allow-popups allow-popups-to-escape-sandbox allow-top-navigation-by-user-activation" srcdoc="' . esc_attr( '<base target="_blank">' . $m->post_content ) . '"></iframe></div>';
		return;
	}
	echo '<table class="widefat striped"><thead><tr><th>When</th><th>To</th><th>Subject</th><th>Delivered</th></tr></thead><tbody>';
	foreach ( get_posts( array( 'post_type' => 'acwp_mail', 'numberposts' => 100 ) ) as $m ) {
		echo '<tr><td>' . esc_html( get_the_date( 'M j, g:i A', $m ) ) . '</td><td>' . esc_html( get_post_meta( $m->ID, '_to', true ) ) . '</td><td><a href="' . esc_url( admin_url( 'admin.php?page=acwp-outbox&mail=' . $m->ID ) ) . '">' . esc_html( $m->post_title ) . '</a></td><td>' . ( get_post_meta( $m->ID, '_sent', true ) ? 'Sent' : 'Saved here only' ) . '</td></tr>';
	}
	echo '</tbody></table></div>';
}

function acwp_settings_page() {
	if ( isset( $_POST['acwp_settings'] ) && check_admin_referer( 'acwp_settings' ) ) {
		$times = array_filter( array_map( 'trim', explode( ',', sanitize_text_field( wp_unslash( $_POST['times'] ?? '' ) ) ) ) );
		$s     = acwp_settings();
		$s['times']       = $times ?: $s['times'];
		$s['owner_email'] = sanitize_email( wp_unslash( $_POST['owner_email'] ?? '' ) ) ?: $s['owner_email'];
		update_option( 'acwp_settings', $s );
		echo '<div class="notice notice-success"><p>Saved.</p></div>';
	}
	$s = acwp_settings();
	echo '<div class="wrap acwp-admin"><h1>Settings</h1><form method="post">';
	wp_nonce_field( 'acwp_settings' );
	echo '<input type="hidden" name="acwp_settings" value="1"><table class="form-table"><tr><th>Posting times (Central)</th><td><input name="times" value="' . esc_attr( implode( ', ', $s['times'] ) ) . '" class="regular-text"><p class="description">24-hour times, comma separated, like 09:00, 12:00, 18:00.</p></td></tr>'
		. '<tr><th>Owner email</th><td><input name="owner_email" type="email" value="' . esc_attr( $s['owner_email'] ) . '" class="regular-text"><p class="description">Gets every new request and step (instead of Slack).</p></td></tr></table>';
	submit_button( 'Save settings' );
	echo '</form></div>';
}
