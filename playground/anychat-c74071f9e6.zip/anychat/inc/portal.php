<?php
/**
 * Front-end pages, as shortcodes (tools/setup.php makes the pages):
 *   [anychat_waitlist]  /get-featured/  request a feature: details + pick a slot (+ upload right after)
 *   [anychat_portal]    /feature/?t=    one feature: status, pick date, upload, send it over
 *   [anychat_member]    /me/            signed-in member: all their features; else "email me a link"
 * The page markup is a shell; assets/portal.js fills it from the REST API.
 */

defined( 'ABSPATH' ) || exit;

function acwp_enqueue() {
	wp_enqueue_style( 'acwp', ACWP_URL . 'assets/portal.css', array(), ACWP_VERSION );
	wp_enqueue_script( 'acwp', ACWP_URL . 'assets/portal.js', array(), ACWP_VERSION, true );
	wp_add_inline_script( 'acwp', 'window.ACWP=' . wp_json_encode( array(
		'api'   => esc_url_raw( rest_url( 'anychat/v1/' ) ),
		'types' => acwp_content_types(),
		'me'    => home_url( '/me/' ),
	) ) . ';', 'before' );
}

add_shortcode( 'anychat_waitlist', function () {
	acwp_enqueue();
	return '<div class="acwp" data-acwp="waitlist"><noscript>Turn on JavaScript to request a feature.</noscript></div>';
} );

add_shortcode( 'anychat_portal', function () {
	acwp_enqueue();
	$t = isset( $_GET['t'] ) ? preg_replace( '/[^A-Za-z0-9_-]/', '', wp_unslash( $_GET['t'] ) ) : '';
	return '<div class="acwp" data-acwp="portal" data-token="' . esc_attr( $t ) . '"><noscript>Turn on JavaScript to upload.</noscript></div>';
} );

add_shortcode( 'anychat_member', function () {
	acwp_enqueue();
	$notice = '';
	if ( isset( $_GET['link'] ) ) {
		$notice = '<p class="acwp-msg no">That link expired or was already used. Ask for a new one below.</p>';
	}
	if ( isset( $_GET['founding'] ) ) {
		$notice = '<p class="acwp-msg go">Phone confirmed. You are a Founding Member: one free feature every 3 months.</p>';
	}
	if ( ! is_user_logged_in() ) {
		return '<div class="acwp">' . $notice . '<section class="acwp-card"><h2>Your member page</h2><p>Enter the email you used to sign up and we will send you a sign-in link. No password needed.</p>'
			. '<form data-acwp="login"><label>Email<input type="email" name="email" required autocomplete="email"></label><button class="acwp-btn">Email me a link</button><p class="acwp-msg" hidden></p></form></section></div>';
	}
	$u   = wp_get_current_user();
	$ids = get_posts( array( 'post_type' => 'acwp_feature', 'post_status' => 'any', 'numberposts' => -1, 'fields' => 'ids', 'meta_key' => '_acwp_email', 'meta_value' => strtolower( $u->user_email ), 'orderby' => 'date', 'order' => 'DESC' ) );
	$founding = get_user_meta( $u->ID, 'acwp_founding', true );
	$out = '<div class="acwp">' . $notice . '<section class="acwp-card"><p class="acwp-kicker">Your member page</p><h2>Hi ' . esc_html( $u->first_name ?: $u->display_name ) . '</h2>'
		. '<p>' . ( $founding ? 'Founding Member: one free feature every 3 months.' : 'Every feature you get on We Are One Lou, and how it did.' ) . '</p>'
		. '<p><a class="acwp-btn" href="' . esc_url( home_url( '/get-featured/' ) ) . '">Request a feature</a> <a class="acwp-link" href="' . esc_url( wp_logout_url( home_url( '/me/' ) ) ) . '">Sign out</a></p></section>';
	if ( ! $ids ) {
		$out .= '<section class="acwp-card"><p>No features yet.</p></section>';
	}
	foreach ( $ids as $id ) {
		$f   = acwp_feature( $id );
		$s   = acwp_statuses()[ $f['status'] ] ?? array( 'label' => $f['status'], 'tone' => '' );
		$n   = count( acwp_feature_files( $id ) );
		$m   = (array) get_post_meta( $id, '_acwp_metrics', true );
		$url = get_post_meta( $id, '_acwp_post_url', true );
		$out .= '<section class="acwp-card acwp-row"><div><span class="acwp-pill ' . esc_attr( $s['tone'] ) . '">' . esc_html( $s['label'] ) . '</span>'
			. '<h3>' . esc_html( $f['business'] ?: $f['event'] ?: 'Your feature' ) . '</h3><p>' . esc_html( acwp_slot_label( $f['slot_at'] ) ) . ' · ' . $n . ' file' . ( 1 === $n ? '' : 's' ) . '</p>'
			. ( array_filter( $m ) ? '<p class="acwp-stats">' . esc_html( implode( ' · ', array_map( fn( $k, $v ) => number_format( (int) $v ) . ' ' . $k, array_keys( array_filter( $m ) ), array_filter( $m ) ) ) ) . '</p>' : '' )
			. '</div><div class="acwp-actions">' . ( $url ? '<a class="acwp-link" href="' . esc_url( $url ) . '" target="_blank" rel="noopener">See the post</a>' : '' )
			. '<a class="acwp-btn" href="' . esc_url( acwp_portal_url( $f ) ) . '">Open</a></div></section>';
	}
	return $out . '</div>';
} );
