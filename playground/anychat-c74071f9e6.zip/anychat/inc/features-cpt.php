<?php
/** The Feature post type: one post per feature request. Fields live in _acwp_* post meta. */

defined( 'ABSPATH' ) || exit;

function acwp_register_feature_type() {
	register_post_type( 'acwp_feature', array(
		'labels'       => array( 'name' => 'Features', 'singular_name' => 'Feature' ),
		'public'       => false,
		'show_ui'      => false, // the Features board (admin-board.php) is the UI
		'supports'     => array( 'title', 'author' ),
		'capability_type' => 'post',
		'map_meta_cap' => true,
	) );
}
add_action( 'init', 'acwp_register_feature_type' );

/**
 * Create a feature. $f = name, email, business, handle, content_type, story, event, event_date, message, slot_at, user_id.
 * Returns the feature array.
 */
function acwp_create_feature( $f, $status = 'requested' ) {
	$id = wp_insert_post( array(
		'post_type'   => 'acwp_feature',
		'post_status' => 'publish',
		'post_title'  => trim( ( $f['business'] ?? '' ) ?: ( $f['name'] ?? 'Feature' ) ),
		'post_author' => (int) ( $f['user_id'] ?? 0 ),
	), true );
	if ( is_wp_error( $id ) ) {
		return $id;
	}
	$keep = array( 'name', 'email', 'phone', 'founding', 'business', 'handle', 'content_type', 'story', 'event', 'event_date', 'message', 'slot_at', 'source' );
	acwp_set( $id, array_intersect_key( $f, array_flip( $keep ) ) + array( 'status' => $status, 'token' => acwp_new_token(), 'notes' => '' ) );
	acwp_log( $id, $status );
	return acwp_feature( $id );
}

/** Files attached to a feature (WordPress media with post_parent = feature). */
function acwp_feature_files( $id ) {
	$out = array();
	foreach ( get_children( array( 'post_parent' => $id, 'post_type' => 'attachment', 'orderby' => 'date', 'order' => 'ASC' ) ) as $a ) {
		$meta  = wp_get_attachment_metadata( $a->ID ) ?: array();
		$mime  = get_post_mime_type( $a );
		$out[] = array(
			'id'   => $a->ID,
			'url'  => wp_get_attachment_url( $a->ID ),
			'type' => str_starts_with( (string) $mime, 'video' ) ? 'video' : 'image',
			'name' => get_the_title( $a ),
			'size' => (int) ( $meta['filesize'] ?? @filesize( get_attached_file( $a->ID ) ) ),
			'w'    => (int) ( $meta['width'] ?? 0 ),
			'h'    => (int) ( $meta['height'] ?? 0 ),
		);
	}
	return $out;
}
