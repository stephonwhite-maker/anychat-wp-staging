<?php
/**
 * Member accounts: a WordPress user per email (role anychat_member), signed in by magic link. No passwords.
 * Founding Member = the member confirmed their phone from an email link.
 */

defined( 'ABSPATH' ) || exit;

/** Find or make the member account for this email. */
function acwp_member( $email, $name = '' ) {
	$email = strtolower( sanitize_email( $email ) );
	$u     = get_user_by( 'email', $email );
	if ( $u ) {
		return $u;
	}
	$login = sanitize_user( current( explode( '@', $email ) ), true ) ?: 'member';
	while ( username_exists( $login ) ) {
		$login .= wp_rand( 0, 9 );
	}
	$id = wp_insert_user( array(
		'user_login' => $login, 'user_email' => $email, 'user_pass' => wp_generate_password( 32 ),
		'display_name' => $name ?: $login, 'first_name' => $name, 'role' => 'anychat_member',
	) );
	return is_wp_error( $id ) ? $id : get_user_by( 'id', $id );
}

/** One-time sign-in link, good for 30 minutes. */
function acwp_login_link( $user_id, $to = '/me/' ) {
	$key = wp_generate_password( 32, false );
	update_user_meta( $user_id, 'acwp_login', array( 'hash' => wp_hash_password( $key ), 'exp' => time() + 30 * MINUTE_IN_SECONDS ) );
	return add_query_arg( array( 'acwp_login' => $user_id . '.' . $key, 'to' => rawurlencode( $to ) ), home_url( '/' ) );
}

add_action( 'init', function () {
	if ( empty( $_GET['acwp_login'] ) ) {
		return;
	}
	[ $uid, $key ] = array_pad( explode( '.', sanitize_text_field( wp_unslash( $_GET['acwp_login'] ) ), 2 ), 2, '' );
	$saved = get_user_meta( (int) $uid, 'acwp_login', true );
	$to    = isset( $_GET['to'] ) ? wp_validate_redirect( home_url( rawurldecode( wp_unslash( $_GET['to'] ) ) ), home_url( '/me/' ) ) : home_url( '/me/' );
	if ( ! $saved || $saved['exp'] < time() || ! wp_check_password( $key, $saved['hash'] ) ) {
		wp_safe_redirect( add_query_arg( 'link', 'expired', home_url( '/me/' ) ) );
		exit;
	}
	delete_user_meta( (int) $uid, 'acwp_login' ); // single use
	wp_set_current_user( (int) $uid );
	wp_set_auth_cookie( (int) $uid, true );
	wp_safe_redirect( $to );
	exit;
} );

/** Email a sign-in link. Always answers the same way so nobody can test which emails have accounts. */
function acwp_send_login( $email ) {
	$u = get_user_by( 'email', strtolower( sanitize_email( $email ) ) );
	if ( $u ) {
		acwp_mail( $u->user_email, 'Your sign-in link', array( 'Tap the button to open your member page. The link works once and expires in 30 minutes.' ), array( 'button' => array( 'Sign in', acwp_login_link( $u->ID ) ) ) );
	}
	return true;
}

/** Phone confirm: a typed phone proves nothing, so the member confirms it from their email (same as WAOL). */
function acwp_phone_confirm_link( $user_id, $phone ) {
	$key = wp_generate_password( 24, false );
	update_user_meta( $user_id, 'acwp_phone_pending', array( 'phone' => $phone, 'hash' => wp_hash_password( $key ), 'exp' => time() + 7 * DAY_IN_SECONDS ) );
	return add_query_arg( 'acwp_phone', $user_id . '.' . $key, home_url( '/me/' ) );
}

add_action( 'init', function () {
	if ( empty( $_GET['acwp_phone'] ) ) {
		return;
	}
	[ $uid, $key ] = array_pad( explode( '.', sanitize_text_field( wp_unslash( $_GET['acwp_phone'] ) ), 2 ), 2, '' );
	$p = get_user_meta( (int) $uid, 'acwp_phone_pending', true );
	if ( $p && $p['exp'] > time() && wp_check_password( $key, $p['hash'] ) ) {
		update_user_meta( (int) $uid, 'acwp_phone', $p['phone'] );
		update_user_meta( (int) $uid, 'acwp_founding', time() );
		delete_user_meta( (int) $uid, 'acwp_phone_pending' );
		wp_safe_redirect( add_query_arg( 'founding', '1', home_url( '/me/' ) ) );
		exit;
	}
	wp_safe_redirect( add_query_arg( 'link', 'expired', home_url( '/me/' ) ) );
	exit;
} );

/**
 * A new feature request from the waitlist form. Returns the feature or WP_Error.
 * $b keys: name, email, phone, business, handle, contentType, story, event, eventDate, message, slotDate, slotTime.
 */
function acwp_submit_request( $b ) {
	$email = strtolower( sanitize_email( $b['email'] ?? '' ) );
	$name  = sanitize_text_field( $b['name'] ?? '' );
	if ( ! $name || ! is_email( $email ) ) {
		return new WP_Error( 'form', 'Add your name and a working email.' );
	}
	$phone_raw = trim( (string) ( $b['phone'] ?? '' ) );
	$phone     = acwp_phone( $phone_raw );
	if ( $phone_raw && ! $phone ) {
		return new WP_Error( 'form', 'Check your phone number (10 digits).' );
	}
	$at = acwp_check_slot( $b['slotDate'] ?? '', $b['slotTime'] ?? '', $email );
	if ( is_wp_error( $at ) ) {
		return $at;
	}
	$u = acwp_member( $email, $name );
	if ( is_wp_error( $u ) ) {
		return new WP_Error( 'form', 'We could not save your request. Try again in a minute.' );
	}
	$ct = in_array( $b['contentType'] ?? '', acwp_content_types(), true ) ? $b['contentType'] : '';
	$f  = acwp_create_feature( array(
		'user_id' => $u->ID, 'name' => $name, 'email' => $email, 'founding' => acwp_is_founding( $email ) ? 1 : 0,
		'business' => sanitize_text_field( $b['business'] ?? '' ), 'handle' => acwp_handle( $b['handle'] ?? '' ),
		'content_type' => $ct, 'story' => substr( sanitize_text_field( $b['story'] ?? '' ), 0, 200 ),
		'event' => sanitize_text_field( $b['event'] ?? '' ),
		'event_date' => preg_match( '/^\d{4}-\d{2}-\d{2}$/', $b['eventDate'] ?? '' ) ? $b['eventDate'] : '',
		'message' => sanitize_textarea_field( $b['message'] ?? '' ), 'slot_at' => $at,
	) );
	if ( is_wp_error( $f ) ) {
		return $f;
	}
	$lines = array(
		sprintf( 'Hi %s, you asked for <b>%s</b>. We review every request within 24 hours, and you will get an email as soon as it is approved.', esc_html( $name ), esc_html( acwp_slot_label( $at ) ) ),
		'You can upload your photos and videos now, so they are ready when you are approved.',
	);
	acwp_mail( $email, 'We got your request', $lines, array( 'button' => array( 'Open your feature page', acwp_portal_url( $f ) ), 'feature' => $f['id'] ) );
	if ( $phone && ! $f['founding'] ) {
		acwp_mail( $email, 'Confirm your phone to unlock Founding Member', array( sprintf( 'Confirm %s as your phone number for We Are One Lou. That unlocks Founding Member access: a free feature every 3 months.', esc_html( acwp_phone_label( $phone ) ) ) ), array( 'button' => array( 'Confirm my phone', acwp_phone_confirm_link( $u->ID, $phone ) ), 'feature' => $f['id'] ) );
	}
	acwp_tell_owner( 'New feature request: ' . ( $f['business'] ?: $name ), array(
		sprintf( '<b>%s</b> (%s) asked for %s.', esc_html( $name ), esc_html( $email ), esc_html( acwp_slot_label( $at ) ) ),
		$f['story'] ? 'The story: ' . esc_html( $f['story'] ) : '',
	), $f['id'] );
	return $f;
}
