<?php
/**
 * Posting slots, same rules as WAOL lib/features.js:
 * - times 9 AM / 12 PM / 6 PM Central (editable on the board's Settings tab)
 * - at least 2 days' notice, one feature per slot
 * - Founding Members (confirmed phone) get one free feature every 90 days; others get one feature.
 */

defined( 'ABSPATH' ) || exit;

function acwp_settings() {
	$s = wp_parse_args( (array) get_option( 'acwp_settings', array() ), array(
		'times'      => array( '09:00', '12:00', '18:00' ),
		'min_days'   => 2,
		'every_days' => 90,
		'owner_email' => get_option( 'admin_email' ),
	) );
	$s['times'] = array_values( array_filter( (array) $s['times'], fn( $t ) => preg_match( '/^([01]\d|2[0-3]):[0-5]\d$/', $t ) ) );
	sort( $s['times'] );
	return $s;
}

/** Unix time for a Central wall-clock date (Y-m-d) + time (H:i). Daylight saving handled by PHP. */
function acwp_zoned( $date, $time ) {
	$d = DateTime::createFromFormat( 'Y-m-d H:i', "$date $time", new DateTimeZone( ACWP_TZ ) );
	return $d ? $d->getTimestamp() : 0;
}

/** Slot timestamps already taken. */
function acwp_taken_slots( $except_id = 0 ) {
	$ids = get_posts( array(
		'post_type' => 'acwp_feature', 'post_status' => 'any', 'numberposts' => -1, 'fields' => 'ids',
		'meta_query' => array( array( 'key' => '_acwp_status', 'value' => acwp_holding_statuses(), 'compare' => 'IN' ) ),
	) );
	$taken = array();
	foreach ( $ids as $id ) {
		if ( (int) $id !== (int) $except_id ) {
			$taken[ (int) get_post_meta( $id, '_acwp_slot_at', true ) ] = true;
		}
	}
	return $taken;
}

/** Open slots for the next $days days, grouped by date: [ 'Y-m-d' => [ ['at'=>ts,'time'=>'12:00','label'=>'12 PM'], ... ] ]. */
function acwp_open_slots( $days = 28 ) {
	$s     = acwp_settings();
	$taken = acwp_taken_slots();
	$tz    = new DateTimeZone( ACWP_TZ );
	$day   = new DateTime( 'today', $tz );
	$day->modify( '+' . (int) $s['min_days'] . ' days' );
	$out = array();
	for ( $i = 0; $i < $days; $i++, $day->modify( '+1 day' ) ) {
		$date = $day->format( 'Y-m-d' );
		foreach ( $s['times'] as $t ) {
			$at = acwp_zoned( $date, $t );
			if ( $at && empty( $taken[ $at ] ) && $at > time() + $s['min_days'] * DAY_IN_SECONDS - HOUR_IN_SECONDS ) {
				$out[ $date ][] = array( 'at' => $at, 'time' => $t, 'label' => wp_date( 'g:i A', $at, $tz ) );
			}
		}
	}
	return $out;
}

/**
 * Check a requested slot for this email. Returns the slot timestamp or WP_Error with a plain-language reason.
 */
function acwp_check_slot( $date, $time, $email, $except_id = 0 ) {
	$s = acwp_settings();
	if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $date ) || ! in_array( $time, $s['times'], true ) ) {
		return new WP_Error( 'slot', 'Pick a date and one of the posting times.' );
	}
	$at = acwp_zoned( $date, $time );
	if ( $at < time() + $s['min_days'] * DAY_IN_SECONDS - HOUR_IN_SECONDS ) {
		return new WP_Error( 'slot', sprintf( 'Pick a time at least %d days from now.', $s['min_days'] ) );
	}
	if ( ! empty( acwp_taken_slots( $except_id )[ $at ] ) ) {
		return new WP_Error( 'slot', 'Someone just took that time. Pick another one.' );
	}
	// One free feature per 90 days for Founding Members, one feature total for everyone else.
	$mine = get_posts( array(
		'post_type' => 'acwp_feature', 'post_status' => 'any', 'numberposts' => -1, 'fields' => 'ids',
		'meta_query' => array(
			array( 'key' => '_acwp_email', 'value' => strtolower( $email ) ),
			array( 'key' => '_acwp_status', 'value' => acwp_holding_statuses(), 'compare' => 'IN' ),
		),
	) );
	$mine = array_diff( $mine, array( $except_id ) );
	if ( $mine ) {
		$founding = acwp_is_founding( $email );
		if ( ! $founding ) {
			return new WP_Error( 'limit', 'You already have a feature with us. Confirm your phone number to become a Founding Member and get one every 3 months.' );
		}
		foreach ( $mine as $id ) {
			$other = (int) get_post_meta( $id, '_acwp_slot_at', true );
			if ( abs( $other - $at ) < $s['every_days'] * DAY_IN_SECONDS ) {
				return new WP_Error( 'limit', 'Founding Members get one free feature every 3 months. Pick a date at least 90 days from your other feature.' );
			}
		}
	}
	return $at;
}

function acwp_is_founding( $email ) {
	$u = get_user_by( 'email', $email );
	return $u && get_user_meta( $u->ID, 'acwp_founding', true );
}
