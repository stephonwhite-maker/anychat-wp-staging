<?php
/**
 * Plugin Name: Anychat
 * Description: Anychat on WordPress. Side-by-side copy of WAOL Features: member accounts, uploads, portal and a Features board in wp-admin. Live Anychat on Vercel is not touched.
 * Version: 0.1.0
 * Author: FORTHEWHEN
 * Requires PHP: 8.1
 */

defined( 'ABSPATH' ) || exit;

define( 'ACWP_VERSION', '0.1.0' );
define( 'ACWP_DIR', __DIR__ );
define( 'ACWP_URL', plugin_dir_url( __FILE__ ) );

foreach ( array( 'helpers', 'roles', 'features-cpt', 'slots', 'mail', 'members', 'uploads', 'rest', 'portal', 'admin-board' ) as $part ) {
	require_once ACWP_DIR . "/inc/{$part}.php";
}

register_activation_hook( __FILE__, function () {
	acwp_add_roles();
	acwp_register_feature_type();
	flush_rewrite_rules();
} );
