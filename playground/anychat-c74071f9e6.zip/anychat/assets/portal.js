/* Anychat on WordPress: waitlist form, feature portal (chunked, resumable uploads) and sign-in form. */
(() => {
  const C = window.ACWP || {};
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const api = async (path, opts = {}) => {
    const r = await fetch(C.api + path, opts);
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.message || 'That didn’t go through. Try again.');
    return j;
  };
  const post = (path, data) => api(path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) });
  const say = (el, text, tone = '') => { el.hidden = !text; el.className = 'acwp-msg ' + tone; el.innerHTML = text; };

  /* ---------- slot picker (shared) ---------- */
  async function slotPicker(box) {
    const { slots } = await api('slots');
    const days = Object.keys(slots);
    if (!days.length) { box.innerHTML = '<p>No open times right now. Check back soon.</p>'; return () => null; }
    const dayLabel = d => new Date(d + 'T12:00:00').toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
    box.innerHTML = '<div class="acwp-days">' + days.map((d, i) => `<button type="button" class="acwp-day${i ? '' : ' on'}" data-d="${d}">${dayLabel(d)}</button>`).join('') + '</div><div class="acwp-times"></div>';
    let pick = null;
    const times = box.querySelector('.acwp-times');
    const show = d => {
      pick = null;
      times.innerHTML = slots[d].map(s => `<button type="button" class="acwp-time" data-d="${d}" data-t="${s.time}">${esc(s.label)}</button>`).join('');
    };
    box.addEventListener('click', e => {
      const day = e.target.closest('.acwp-day'), t = e.target.closest('.acwp-time');
      if (day) { box.querySelectorAll('.acwp-day').forEach(b => b.classList.toggle('on', b === day)); show(day.dataset.d); }
      if (t) { box.querySelectorAll('.acwp-time').forEach(b => b.classList.toggle('on', b === t)); pick = { slotDate: t.dataset.d, slotTime: t.dataset.t }; }
    });
    show(days[0]);
    return () => pick;
  }

  /* ---------- waitlist ---------- */
  async function waitlist(root) {
    root.innerHTML = `<section class="acwp-card"><p class="acwp-kicker">Get featured</p><h2>Join the waitlist</h2>
      <p>Tell us what you want featured and pick a time. We review every request within 24 hours.</p>
      <form class="acwp-form">
        <label>Your name<input name="name" required autocomplete="name"></label>
        <label>Email<input name="email" type="email" required autocomplete="email"></label>
        <label>Phone <span class="acwp-opt">(optional, unlocks Founding Member)</span><input name="phone" type="tel" autocomplete="tel"></label>
        <label>Business or brand<input name="business"></label>
        <label>Instagram<input name="handle" placeholder="@yourhandle"></label>
        <label>What is it?<select name="contentType"><option value="">Pick one</option>${(C.types || []).map(t => `<option>${esc(t)}</option>`).join('')}</select></label>
        <label>The story, in one line<input name="story" maxlength="200"></label>
        <label>Event name <span class="acwp-opt">(if it’s an event)</span><input name="event"></label>
        <label>Event date<input name="eventDate" type="date"></label>
        <label>Anything else<textarea name="message" rows="3"></textarea></label>
        <input name="website" class="acwp-hp" tabindex="-1" autocomplete="off" aria-hidden="true">
        <h3>Pick your time</h3><div class="acwp-slots">Loading times…</div>
        <button class="acwp-btn">Send my request</button><p class="acwp-msg" hidden></p>
      </form></section>`;
    const form = root.querySelector('form'), msg = form.querySelector('.acwp-msg');
    const getPick = await slotPicker(form.querySelector('.acwp-slots'));
    form.addEventListener('submit', async e => {
      e.preventDefault();
      const pick = getPick();
      if (!pick) return say(msg, 'Pick a day and a time.', 'no');
      const btn = form.querySelector('.acwp-btn'); btn.disabled = true;
      try {
        const res = await post('request', { ...Object.fromEntries(new FormData(form)), ...pick });
        location.href = res.portal + '&new=1';
      } catch (err) { say(msg, esc(err.message), 'no'); btn.disabled = false; }
    });
  }

  /* ---------- chunked, resumable upload of one file ---------- */
  async function uploadFile(token, file, chunk, onProgress) {
    // Same file picked again resumes where it stopped (id kept in this browser).
    const key = 'acwp-up:' + token + ':' + file.name + ':' + file.size + ':' + file.lastModified;
    let id = null;
    try { id = localStorage.getItem(key); } catch {}
    if (!id) { id = (crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) + Math.random().toString(16).slice(2)).replace(/-/g, ''); try { localStorage.setItem(key, id); } catch {} }
    const total = Math.max(1, Math.ceil(file.size / chunk));
    let have = new Set();
    try { have = new Set((await api(`upload/status?t=${encodeURIComponent(token)}&upload_id=${id}`)).received); } catch {}
    let last = null;
    for (let i = 0; i < total; i++) {
      if (have.has(i) && i < total - 1) { onProgress((i + 1) / total); continue; }
      const body = new FormData();
      Object.entries({ t: token, upload_id: id, index: i, total, name: file.name, type: file.type || guessType(file.name), size: file.size }).forEach(([k, v]) => body.append(k, v));
      body.append('chunk', file.slice(i * chunk, (i + 1) * chunk), 'chunk');
      for (let attempt = 1; ; attempt++) {
        try { last = await api('upload', { method: 'POST', body }); break; }
        catch (err) {
          if (attempt >= 4 || /photos|videos|2 GB|up to|closed|mixed up/.test(err.message)) throw err;
          await new Promise(r => setTimeout(r, 1000 * attempt * attempt)); // 1s, 4s, 9s
        }
      }
      onProgress((i + 1) / total);
    }
    try { localStorage.removeItem(key); } catch {}
    return last;
  }
  const guessType = n => ({ jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', heic: 'image/heic', webp: 'image/webp', mp4: 'video/mp4', mov: 'video/quicktime', m4v: 'video/x-m4v' }[n.split('.').pop().toLowerCase()] || '');

  /* ---------- portal ---------- */
  async function portal(root) {
    const token = root.dataset.token;
    if (!token) { root.innerHTML = '<section class="acwp-card"><h2>This link is missing a piece</h2><p>Open the link from your email again, or <a href="' + esc(C.me) + '">go to your member page</a>.</p></section>'; return; }
    let v;
    try { v = await api('feature?t=' + encodeURIComponent(token)); }
    catch (e) { root.innerHTML = '<section class="acwp-card"><h2>This link is not active</h2><p>' + esc(e.message) + ' <a href="' + esc(C.me) + '">Go to your member page</a>.</p></section>'; return; }
    const isNew = new URLSearchParams(location.search).has('new');
    const render = () => {
      root.innerHTML = `
        ${isNew ? '<p class="acwp-msg go">Request sent. Upload your photos and videos below so they’re ready when you’re approved.</p>' : ''}
        <section class="acwp-card"><span class="acwp-pill ${esc(v.tone)}">${esc(v.label)}</span>
          <h2>${esc(v.business || v.name)}</h2><p>${esc(v.slot_label)}</p>
          ${v.change_note ? `<p class="acwp-msg wait"><b>What to change:</b> ${esc(v.change_note)}</p>` : ''}
          ${v.post_url ? `<p><a class="acwp-btn" href="${esc(v.post_url)}" target="_blank" rel="noopener">See your post</a></p>` : ''}
        </section>
        ${v.can_pick ? '<section class="acwp-card"><h3>Pick your date</h3><div class="acwp-slots">Loading…</div><button class="acwp-btn" data-act="pick">Book this time</button><p class="acwp-msg" hidden></p></section>' : ''}
        ${v.can_upload ? `<section class="acwp-card"><h3>Your photos and videos</h3>
          <p>Up to ${v.max_files} files. Big videos are fine: they upload in pieces, and if your connection drops, pick the same file again to pick up where it stopped.</p>
          <label class="acwp-drop"><input type="file" multiple accept="image/*,video/*" hidden><span>Tap to add files</span></label>
          <div class="acwp-queue"></div>
          <div class="acwp-files">${v.files.map(f => `<div class="acwp-file">${f.type === 'video' ? `<video src="${esc(f.url)}#t=0.5" muted playsinline preload="metadata"></video>` : `<img src="${esc(f.url)}" alt="">`}<span>${esc(f.name)}</span>${v.can_upload ? `<button class="acwp-x" data-rm="${f.id}" aria-label="Remove">×</button>` : ''}</div>`).join('') || '<p class="acwp-muted">No files yet.</p>'}</div>
        </section>` : ''}
        ${v.can_send ? `<section class="acwp-card"><h3>Send it over</h3>
          <label>Caption idea <span class="acwp-opt">(optional)</span><textarea rows="3" class="acwp-caption">${esc(v.caption)}</textarea></label>
          <button class="acwp-btn" data-act="send">${v.content_ready ? 'Update my files' : 'My files are ready'}</button><p class="acwp-msg" hidden></p></section>` : ''}
        <p class="acwp-foot"><a href="${esc(C.me)}">Your member page</a></p>`;
      wire();
    };
    const wire = async () => {
      const input = root.querySelector('input[type=file]');
      if (input) input.addEventListener('change', async () => {
        const queue = root.querySelector('.acwp-queue');
        for (const file of input.files) {
          const row = document.createElement('div'); row.className = 'acwp-up';
          row.innerHTML = `<span>${esc(file.name)}</span><progress max="1" value="0"></progress><em>Starting…</em>`;
          queue.append(row);
          const bar = row.querySelector('progress'), note = row.querySelector('em');
          try {
            await uploadFile(token, file, v.chunk, p => { bar.value = p; note.textContent = Math.round(p * 100) + '%'; });
            note.textContent = 'Uploaded';
          } catch (e) { note.textContent = e.message; row.classList.add('bad'); }
        }
        v = await api('feature?t=' + encodeURIComponent(token)); render();
      });
      root.querySelectorAll('[data-rm]').forEach(b => b.addEventListener('click', async () => {
        if (!confirm('Remove this file?')) return;
        try { v = await post('upload/remove', { t: token, id: b.dataset.rm }); render(); } catch (e) { alert(e.message); }
      }));
      const send = root.querySelector('[data-act=send]');
      if (send) send.addEventListener('click', async () => {
        const msg = send.nextElementSibling; send.disabled = true;
        try { v = await post('feature/send', { t: token, caption: root.querySelector('.acwp-caption').value }); render(); root.querySelector('.acwp-card').insertAdjacentHTML('beforebegin', '<p class="acwp-msg go">Got it. We’ll take it from here.</p>'); }
        catch (e) { say(msg, esc(e.message), 'no'); send.disabled = false; }
      });
      const pickBtn = root.querySelector('[data-act=pick]');
      if (pickBtn) {
        const getPick = await slotPicker(root.querySelector('.acwp-slots'));
        pickBtn.addEventListener('click', async () => {
          const msg = pickBtn.nextElementSibling, pick = getPick();
          if (!pick) return say(msg, 'Pick a day and a time.', 'no');
          try { v = await post('feature/pick', { t: token, ...pick }); render(); } catch (e) { say(msg, esc(e.message), 'no'); }
        });
      }
    };
    render();
  }

  /* ---------- sign-in link ---------- */
  function login(form) {
    form.addEventListener('submit', async e => {
      e.preventDefault();
      const msg = form.querySelector('.acwp-msg');
      try { const r = await post('login', { email: form.email.value }); say(msg, esc(r.message), 'go'); } catch (err) { say(msg, esc(err.message), 'no'); }
    });
  }

  document.querySelectorAll('[data-acwp=waitlist]').forEach(waitlist);
  document.querySelectorAll('[data-acwp=portal]').forEach(portal);
  document.querySelectorAll('form[data-acwp=login]').forEach(login);
})();
