<?php
/**
 * Setup for the Anychat WordPress copy. Runs inside WordPress via the Playground blueprint.
 * Re-runnable: pages are matched by slug. Never deletes members, features or uploads.
 */

defined( 'ABSPATH' ) || exit;

update_option( 'blogname', 'We Are One Lou · Anychat (WordPress copy)' );
update_option( 'blogdescription', 'Staging copy. Live Anychat is not affected.' );
update_option( 'permalink_structure', '/%postname%/' );
update_option( 'timezone_string', 'America/Chicago' );
update_option( 'default_comment_status', 'closed' );
update_option( 'users_can_register', 0 ); // members are made by the waitlist, never by wp-login.php
update_option( 'blog_public', 0 );        // staging: ask search engines not to index

if ( function_exists( 'acwp_add_roles' ) ) {
	acwp_add_roles();
}
foreach ( array( 'hello-world' => 'post', 'sample-page' => 'page' ) as $slug => $type ) {
	$p = get_page_by_path( $slug, OBJECT, $type );
	if ( $p ) {
		wp_delete_post( $p->ID, true );
	}
}

$pages = array(
	'get-featured' => array( 'Get featured', '[anychat_waitlist]' ),
	'feature'      => array( 'Your feature', '[anychat_portal]' ),
	'me'           => array( 'Your member page', '[anychat_member]' ),
);
foreach ( $pages as $slug => [ $title, $code ] ) {
	$p    = get_page_by_path( $slug );
	$data = array( 'post_type' => 'page', 'post_status' => 'publish', 'post_name' => $slug, 'post_title' => $title, 'post_content' => "<!-- wp:shortcode -->\n$code\n<!-- /wp:shortcode -->" );
	if ( $p ) {
		$data['ID'] = $p->ID;
	}
	wp_insert_post( $data );
}

// Home = the waitlist page.
update_option( 'show_on_front', 'page' );
update_option( 'page_on_front', get_page_by_path( 'get-featured' )->ID );

flush_rewrite_rules();
echo "Anychat WordPress copy set up.\n";
