<?php
/**
 * Demo data for the public Playground share link ONLY (never run on the local copy or a real host).
 * Made-up members so the Features board has something on it. Re-runnable: skips if demo rows exist.
 */

defined( 'ABSPATH' ) || exit;

if ( get_posts( array( 'post_type' => 'acwp_feature', 'meta_key' => '_acwp_source', 'meta_value' => 'demo', 'numberposts' => 1 ) ) ) {
	return;
}

$tz   = new DateTimeZone( 'America/Chicago' );
$slot = function ( $days, $hour ) use ( $tz ) {
	$d = new DateTime( 'today', $tz );
	$d->modify( "+{$days} days" )->setTime( $hour, 0 );
	return $d->getTimestamp();
};

$rows = array(
	array( 'requested', array( 'name' => 'Demo Member One', 'email' => 'demo1@example.com', 'business' => 'Example Coffee Co.', 'handle' => 'examplecoffee', 'content_type' => 'photo', 'story' => 'Grand opening on Cherokee St.', 'slot_at' => $slot( 4, 12 ) ) ),
	array( 'approved', array( 'name' => 'Demo Member Two', 'email' => 'demo2@example.com', 'business' => 'Example Studio', 'handle' => 'examplestudio', 'content_type' => 'video', 'story' => 'Behind the scenes of a mural.', 'slot_at' => $slot( 6, 18 ) ) ),
	array( 'in_production', array( 'name' => 'Demo Member Three', 'email' => 'demo3@example.com', 'business' => 'Example Bakery', 'handle' => 'examplebakery', 'content_type' => 'photo', 'story' => 'New holiday menu.', 'slot_at' => $slot( 3, 9 ) ) ),
);

foreach ( $rows as [ $status, $f ] ) {
	$u = wp_insert_user( array( 'user_login' => $f['email'], 'user_email' => $f['email'], 'display_name' => $f['name'], 'user_pass' => wp_generate_password( 24 ), 'role' => 'anychat_member' ) );
	$f['user_id'] = is_wp_error( $u ) ? 0 : $u;
	$f['source']  = 'demo';
	acwp_create_feature( $f, $status );
}

echo "Demo features added.\n";
